#!/bin/bash
set -e

VERSION="v0.2.0"
REPO="termcode"
GITHUB_USER="AITechnologyDev"
BINARY="termcode"

echo "=== TermCode $VERSION — публикация на GitHub ==="

# 1. Инициализируем git если нужно
if [ ! -d ".git" ]; then
    git init
    git branch -M main
fi

# 2. Добавляем remote если нет
if ! git remote get-url origin 2>/dev/null; then
    git remote add origin "https://github.com/$GITHUB_USER/$REPO.git"
    echo "Remote добавлен: github.com/$GITHUB_USER/$REPO"
fi

# 3. Коммитим всё
git add -A
git commit -m "release: $VERSION

Features:
- Web search (DuckDuckGo, no API key)
- fetch_page + download_file tools
- Auto-detect context length from Ollama /api/show
- Multi-select Q&A checkbox UI
- EN/RU language switcher
- Syntax highlighting (Go/Python/JS/TS/Rust/Java/Kotlin/SQL/JSON)
- think-block toggle (T key)
- Session load/delete UI
- Goroutine leak prevention
- Path traversal protection" 2>/dev/null || echo "(нечего коммитить)"

# 4. Пушим
echo ""
echo "Пушим на GitHub..."
git push -u origin main

# 5. Создаём тег релиза
git tag -a "$VERSION" -m "TermCode $VERSION" 2>/dev/null || echo "(тег уже существует)"
git push origin "$VERSION" 2>/dev/null || echo "(тег уже запушен)"

echo ""
echo "=== Готово! ==="
echo ""
echo "Теперь создай релиз на GitHub:"
echo "  https://github.com/$GITHUB_USER/$REPO/releases/new"
echo ""
echo "Tag: $VERSION"
echo "Title: TermCode $VERSION"
echo ""
echo "Release notes:"
cat << 'NOTES'
## What's new in v0.2.0

### New tools
- `web_search` — DuckDuckGo search, no API key needed
- `fetch_page` — read any web page as plain text
- `download_file` — download assets from the internet (max 50 MB)

### Smarter context
- Auto-detects real context length from Ollama `/api/show`
- Works with 256k context models like `qwen3-coder-next:cloud`

### Better UX
- Multi-select checkbox Q&A when AI asks clarifying questions
- EN/RU language switcher (Ctrl+P → Switch Language)
- Language shown in header bar

### Fixes
- Fixed empty response bug when model replies with only `<think>` blocks
- Fixed Q&A cursor bounds
- Orphaned `</think>` tags from GLM are now filtered correctly

## Recommended free cloud models (no GPU needed)
- `ollama pull qwen3-coder-next:cloud` — 80B, 262k context, free
- `ollama pull glm-4.7:cloud` — fast, free, great for everyday use

## Install on Termux
```bash
pkg install golang git
git clone https://github.com/AITechnologyDev/termcode
cd termcode && bash build-termux.sh
```
NOTES
